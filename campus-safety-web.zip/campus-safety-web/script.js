const db = firebase.firestore();

document.getElementById("sosBtn").addEventListener("click", () => {
  navigator.geolocation.getCurrentPosition((pos) => {
    db.collection("alerts").add({
      lat: pos.coords.latitude,
      lng: pos.coords.longitude,
      status: "ACTIVE",
      timestamp: firebase.firestore.FieldValue.serverTimestamp()
    })
    .then(() => {
      alert("🚨 SOS Sent Successfully!");
    });
  });
});
